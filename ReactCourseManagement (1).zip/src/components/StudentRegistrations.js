import React from 'react';

function StudentRegistrations() {
    return (
        <div>
            <h2>Student Registrations</h2>
            <p>Manage student registrations here.</p>
        </div>
    );
}

export default StudentRegistrations;
