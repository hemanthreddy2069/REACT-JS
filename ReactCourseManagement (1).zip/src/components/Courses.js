import React from 'react';

function Courses() {
    return (
        <div>
            <h2>Courses</h2>
            <p>Manage courses here.</p>
        </div>
    );
}

export default Courses;
