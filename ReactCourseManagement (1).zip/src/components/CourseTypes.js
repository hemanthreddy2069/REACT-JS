import React from 'react';

function CourseTypes() {
    return (
        <div>
            <h2>Course Types</h2>
            <p>Manage course types here.</p>
        </div>
    );
}

export default CourseTypes;
